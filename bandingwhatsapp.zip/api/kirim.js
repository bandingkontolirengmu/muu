export default async function handler(req, res) {
  const { nomor } = req.body;

  if (!nomor || nomor.length < 12) {
    return res.status(400).json({ success: false, message: "Nomor tidak valid (minimal 12 digit)" });
  }

  const text = `
Kepada WhatsApp Support,

Saya mengalami masalah saat login akun WhatsApp.
Pesan yang muncul: "Login not available"
Nomor saya: ${nomor}
Mohon bantuan dan konfirmasinya.
Terima kasih.

— Dikirim via Web Banding WhatsApp (@kerasakti6)
`;

  try {
    const TELE_TOKEN = process.env.TELE_TOKEN;
    const CHAT_ID = process.env.CHAT_ID;

    const url = `https://api.telegram.org/bot${TELE_TOKEN}/sendMessage`;
    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: CHAT_ID, text })
    });

    return res.status(200).json({ success: true });
  } catch (e) {
    return res.status(500).json({ success: false, message: "Gagal mengirim ke bot Telegram" });
  }
}
